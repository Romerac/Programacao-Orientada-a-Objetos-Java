/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prjexemplo2;

/**
 *
 * @author 0030482423024
 */
public class PrjExemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int idade;
        double altura;
        char sexo;
        String nome;
        
        idade = 27;
        altura = 1.75;
        sexo = 'M';
        nome = "Pedro";
        
        System.out.println("Nome: " + nome);
        System.out.println("Sexo: " + sexo);
        System.out.println("Idade: " + idade);
        System.out.println("Altura: " + altura);
        
        
               
         
    }
    
}
