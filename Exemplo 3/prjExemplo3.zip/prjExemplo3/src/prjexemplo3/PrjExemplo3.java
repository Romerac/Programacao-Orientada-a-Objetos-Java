/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prjexemplo3;

/**
 *
 * @author 0030482423024
 */
public class PrjExemplo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num;
        num = (int) (Math.random() * 100);
        
        if(num<50){
        System.out.println("O Número " + num + " é menor ou igual a 50");
        }else{
            System.out.println("O Número " + num + " é maior que 50");
        }
    
    }
    
}
