/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482423024
 */
public class Exemplo6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                
        int cont, num;
        
        num = (int) (Math.random() * 100);
        System.out.println("\t\t\tTABUADA DO " + num);
        
        cont = 1;
        
        do {
            System.out.println(num + " x " + cont + " = " + cont * num);
            cont++;
        } while (cont<11);
    }
    
}
