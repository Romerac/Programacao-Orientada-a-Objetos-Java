/**
 *
 * @author romerac
 */
public class Circulo {
    
    private double raio;
    
    public void setRaio(double r){
        raio=r;
    }
    
    public double getRaio(){
        return(raio);
    }
    
    public double calcArea (){
        System.out.println("\nCálculo de Área:\nPI * Raio ((" + getRaio() + ")²)");
        return(Math.PI * (Math.pow(raio,2)));
    }
    
    public double calcPerimetro(){
        System.out.println("\nCálculo de Perimetro:\n2 * PI * Raio (" + getRaio() + ")");
        return((2 * Math.PI) * (raio));
    }
    
    public double calcDiametro(){
        System.out.println("\nCálculo de Diametro:\n2 * Raio (" + getRaio() + ")");
        return(2 * raio);
    }
    
}
