
import java.util.Scanner;

/**
 *
 * @author romerac
 */
public class Aplic {


     public static void main(String[] args) {
         Scanner Entrada = new Scanner (System.in);
         
         double medRaio;
         int opcao;
         String unidade;
         
         
         System.out.println("Digite a unidade de medida: ");
         unidade = Entrada.next();
         
         // Instanciação de um objeto da classe Retangulo
        //e chamada do método construtor.
        Circulo objCirc = new Circulo(unidade);
        
         
         System.out.println("Digite a medida do raio: ");
         medRaio = Entrada.nextDouble();
                 
         
         objCirc.setRaio(medRaio);
         
         System.out.println("Medida escolhida do raio: " + objCirc.getRaio());
         
         
        
        do{
            //MENU
            System.out.println("\n\n-1. Consultar Área.");
            System.out.println("-2. Consultar Perímetro.");
            System.out.println("-3. Consultar Diametro.");
            System.out.println("-4. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
            
            
            //
            opcao = Entrada.nextInt();
            
            switch (opcao) {
                case 1:
                    System.out.println("Medida da área do retângulo: " + objCirc.calcArea() + " " + objCirc.getUnidadeMedida() + "²");
                    break;
                case 2:
                    System.out.println("Medida do perímetro do retângulo: " + objCirc.calcPerimetro() + " " + objCirc.getUnidadeMedida());
                    break;
                case 3:
                    System.out.println("Medida da diagonal do retângulo: " + objCirc.calcDiametro() + " " + objCirc.getUnidadeMedida());
                    break;
                default:
                    break;
            }
            
        }while (opcao < 4);
         
    }
    
}
