/**
 *
 * @author romerac
 */
public class Aplic {
    public static void main(String[] args) {
        
    //Definição do ponteiro para um objeto:
    Retangulo objRet;

    //Instanciação (alocação):
    objRet = new Retangulo();
    
    //Passgem de mensagens
    objRet.setAltura(5.0);
    objRet.setBase(8.0);
    
    System.out.println("Medida da área do retângulo: " + objRet.calcArea());
    System.out.println("Medida do perímetro do retângulo: " + objRet.calcPerimetro());
    System.out.println("Medida do altura do retângulo: " + objRet.getAltura());
    System.out.println("Medida do base do retângulo: " + objRet.getBase());
    
    
    
    }
    
}