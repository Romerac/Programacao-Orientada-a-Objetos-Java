
/**
 *
 * @author 0030482423009
 */
public class Exemplo1 {
    public static void main(String[] args) {
        System.out.print("programação Orientada a Objetos Hello World");
    }
    
}
