/**
 *
 * @author Tiago Camargo
 */
public class Exemplo2 {
    public static void main(String[] args) {
        int idade;
        double altura;
        char sexo;
        String nome;
        idade = 27;
        altura = 1.75;
        sexo = 'M';
        nome = "Pedro";
        System.out.println("Nome: " + nome);
        System.out.println("Sexo: " + sexo);
        System.out.println("Idade: " + idade);/*no VB tenho que usar um Cstr, que seria um conversor do int para String. 
        No java ele converte automatico e ai sim faz a concatenação*/
        System.out.println("Altura: " + altura);
                
    }
    
}
