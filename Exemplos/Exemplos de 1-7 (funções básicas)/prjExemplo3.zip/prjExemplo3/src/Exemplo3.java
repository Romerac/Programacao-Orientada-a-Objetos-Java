/**
 *
 * @author Tiago Camargo
 */
public class Exemplo3 {

    public static void main(String[] args) {
        int num;
        num = (int) (Math.random() * 100);
        /*cast => modificador de acesso de endereçamento
        o math.random() é um método de classe ou estático(função), no caso o random irá gerar um número entre 0 e 1 sorteio*/
        if (num <= 50){
            System.out.println("o número " + num +" é menor ou igual a 50");
            
        }else{
            System.out.println("o número " +num+ " é maior que 50");
        }
     
    }
    
}
