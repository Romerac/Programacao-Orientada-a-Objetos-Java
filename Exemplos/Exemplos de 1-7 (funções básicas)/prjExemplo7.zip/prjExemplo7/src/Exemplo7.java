/**
 *
 * @author Tiago
 */
public class Exemplo7 {
    public static void main(String[] args) {
        int [] TabNum;//declaração da variável
        int cont;
        
        TabNum = new int [3];/*criação com o new, similar ao malloc com sizeof
        int *tabNum;
        tabNum = (int*) malloc (sizeof (int)*3);
        */
        TabNum[0] = 34;
        TabNum[1] = 18;
        TabNum[2] = 27;
        for (cont=0; cont<3; cont++){
            System.out.println("Conteudo de TabNum[" + cont + "] = ");
            System.out.println(TabNum[cont]);
        }
    }
    
}
