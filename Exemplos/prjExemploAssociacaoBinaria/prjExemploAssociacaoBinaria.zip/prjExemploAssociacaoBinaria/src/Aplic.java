
import fatec.poo.model.Departamento;
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author romerac
 */
public class Aplic {

    public static void main(String[] args) {
        //instanciação:
        FuncionarioHorista funcHor = new FuncionarioHorista(395,
                                                            "José David",
                                                            "14/05/1987",
                                                            15.80);
        
        FuncionarioMensalista funcMens = new FuncionarioMensalista(849,
                                                            "Yolanda",
                                                            "20/09/1996",
                                                            2000);
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(621,
                                                            "Vitor",
                                                            "09/10/2014",
                                                            10);
        
        Departamento dep1 = new Departamento("TI", "Tecnologia da Informação");
        Departamento dep2 = new Departamento("RH", "Recursos Humanos");
        
    }    
}
