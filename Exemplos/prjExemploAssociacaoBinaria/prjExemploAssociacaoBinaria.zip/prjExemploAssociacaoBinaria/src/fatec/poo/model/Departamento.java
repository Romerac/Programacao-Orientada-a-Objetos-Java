package fatec.poo.model;

/**
 *
 * @author romerac
 */
public class Departamento {
    private String sigla;
    private String nome;

    public Departamento(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public String getSigla() {
        return sigla;
    }

        
    
}
