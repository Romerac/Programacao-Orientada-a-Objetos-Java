package fatec.poo.model;



/**
 **
 ** @author romerac
 **/
abstract public class Funcionario {
    private int registro;
    private String nome;
    private String dtAdmissao;
    private String cargo;
    private Departamento departamento; //ponteiro que permite armazenar o endereço de 
                                       //um objeto da classe departamento
                                       //multiplicidade 1
   
    
    
    public Funcionario (int r, String n, String dta){
        registro = r;
        nome = n;
        dtAdmissao = dta;
    }
    
    //método abstrato
    //apresenta a assinatura do método
    abstract public double calcSalBruto();
    
    public int getRegistro(){
        return(registro);
    }
    
    public String getNome(){
        return(nome);
    }
    
    public String getDtAdmissao(){
        return(dtAdmissao);
    }
    
    public void setCargo(String c){
        cargo = c;
    }
    
    public String getCargo(){
        return(cargo);
    }
    
    public double calcDesconto(){
        return(0.10 * calcSalBruto());
    }
    
    public double calcSalLiquido(){
        return(calcSalBruto() - calcDesconto());
    }

    //retorna o endereço de um objeto
    //da classe departamento.
    public Departamento getDepartamento() {
        return departamento;
    }
    
    //tem como parâmetro de entrada o endereço
    //de um objeto da classe Departamento
    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }
        
}
