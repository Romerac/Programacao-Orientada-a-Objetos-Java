package fatec.poo.model;



/**
 *
 * @author romerac
 */
public class FuncionarioMensalista extends Funcionario{
    private double valSalMin;
    private double numSalMin;
    
    public FuncionarioMensalista(int r, String n, String dta, double nsm){
        super (r, n, dta);
    }
    
    
    public void setNumSalMin(double nsm){
        numSalMin = nsm;
    }
    
    public void setValSalMin(double vsm){
        valSalMin = vsm;
    }
        
    public double calcSalBruto(){
        return(valSalMin * numSalMin);
    }    
}
