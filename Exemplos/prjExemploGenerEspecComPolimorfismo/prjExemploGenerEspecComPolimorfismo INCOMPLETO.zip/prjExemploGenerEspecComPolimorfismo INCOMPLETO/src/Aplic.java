
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author romerac
 */
public class Aplic {
    public static void main(String[] args) {
        //instanciação
        FuncionarioHorista funcHor = new FuncionarioHorista(395,
                                                            "José David",
                                                            "14/05/1987",
                                                            15.80);
        
        FuncionarioMensalista funcMens = new FuncionarioMensalista(849,
                                                            "Yolanda",
                                                            "20/09/1996",
                                                            2000);
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(849,
                                                            "Yolanda",
                                                            "20/09/1996",
                                                            2000);
                
        funcHor.setQtdeHorTrab(90);
        funcHor.setCargo("Motorista");
        System.out.println("Registro: " + funcHor.getRegistro());
        System.out.println("Nome: " + funcHor.getNome());
        System.out.println("Data Admissão: " + funcHor.getDtAdmissao());
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salário Bruto: " + funcHor.calcSalBruto());
        System.out.println("Desconto: " + funcHor.calcDesconto());
        System.out.println("Gratificação: " + funcHor.calcGratificacao());
        System.out.println("Salário Liquido: " + funcHor.calcSalLiquido());
        
        
        funcMens.setCargo("Secretária");
        funcMens.setNumSalMin(3);
        funcMens.setValSalMin(2000);
        System.out.println("\n\nRegistro: " + funcMens.getRegistro());
        System.out.println("Nome: " + funcMens.getNome());
        System.out.println("Data Admissão: " + funcMens.getDtAdmissao());
        System.out.println("Cargo: " + funcMens.getCargo());
        System.out.println("Salário Bruto: " + funcMens.calcSalBruto());
        System.out.println("Desconto: " + funcMens.calcDesconto());
        System.out.println("Salário Liquido: " + funcMens.calcSalLiquido());

    }
    
    
    
}
