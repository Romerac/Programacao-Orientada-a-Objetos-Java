package fatec.poo.model;

/**
 *
 * @author romerac
 */
public class FuncionarioComissionado extends Funcionario{
    private double salBase;
    private double taxaComissao;
    private double totalVendas;
    
    public FuncionarioComissionado(int r, String n, String dta, double txc){
        super(r, n, dta);
        taxaComissao = txc;
    }
    
    public void setSalBase(double sb){
        salBase = sb;
    }
    
    public double getSalBase(){
        return(salBase);
    }
    
    public double getTotalVendas(){
        return(totalVendas);
    }
    
    public double getTaxaComissao(){
        return(taxaComissao);
    }
    
    public void addVendas(double tv){
        totalVendas = tv;
    }
    
    public double calSalBruto(){
        return(salBase * taxaComissao * totalVendas);
    }
    
}