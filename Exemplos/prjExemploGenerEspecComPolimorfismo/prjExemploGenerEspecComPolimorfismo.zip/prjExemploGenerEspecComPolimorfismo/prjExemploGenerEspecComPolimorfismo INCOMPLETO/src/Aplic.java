
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author romerac
 */
public class Aplic {
    public static void main(String[] args) {
        //instanciação
        FuncionarioHorista funcHor = new FuncionarioHorista(395,
                                                            "José David",
                                                            "14/05/1987",
                                                            15.80);
        
        FuncionarioMensalista funcMens = new FuncionarioMensalista(849,
                                                            "Yolanda",
                                                            "20/09/1996",
                                                            2000);
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(621,
                                                            "Vitor",
                                                            "09/10/2014",
                                                            0.1);
                
        funcHor.setQtdeHorTrab(90);
        funcHor.setCargo("Motorista");
        System.out.println("Registro: " + funcHor.getRegistro());
        System.out.println("Nome: " + funcHor.getNome());
        System.out.println("Data Admissão: " + funcHor.getDtAdmissao());
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salário Bruto: " + funcHor.calcSalBruto());
        System.out.println("Desconto: " + funcHor.calcDesconto());
        System.out.println("Gratificação: " + funcHor.calcGratificacao());
        System.out.println("Salário Liquido: " + funcHor.calcSalLiquido());
        
        
        funcMens.setCargo("Secretária");
        funcMens.setNumSalMin(3);
        funcMens.setValSalMin(2000);
        System.out.println("\n\nRegistro: " + funcMens.getRegistro());
        System.out.println("Nome: " + funcMens.getNome());
        System.out.println("Data Admissão: " + funcMens.getDtAdmissao());
        System.out.println("Cargo: " + funcMens.getCargo());
        System.out.println("Salário Bruto: " + funcMens.calcSalBruto());
        System.out.println("Desconto: " + funcMens.calcDesconto());
        System.out.println("Salário Liquido: " + funcMens.calcSalLiquido());
        
        
        funcCom.setCargo("Vendedor");
        funcCom.setSalBase(3000);
        funcCom.addVendas(15000);
        System.out.println("\n\nRegistro: " + funcCom.getRegistro());
        System.out.println("Nome: " + funcCom.getNome());
        System.out.println("Data Admissão: " + funcCom.getDtAdmissao());
        System.out.println("Total de vendas: " + funcCom.getTotalVendas());
        System.out.println("Cargo: " + funcCom.getCargo());
        System.out.println("Taxa de Comissão: " + funcCom.getTaxaComissao()*100 + "%");
        System.out.println("Salário Bruto: " + funcCom.calcSalBruto());
        System.out.println("Salário Liquido: " + funcCom.calcSalLiquido());
        System.out.println("Desconto: " + funcCom.calcDesconto());
        System.out.println("Valor da gratificação: " + funcCom.calcGratificacao());

    }
       
}
