
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
import java.text.DecimalFormat;

/**
 *
 * @author romerac
 */
public class Aplic {
    public static void main(String[] args) {
        
        DecimalFormat df = new DecimalFormat("#, ##0.00");
        //instanciação
        FuncionarioHorista funcHor = new FuncionarioHorista(395,
                                                            "José David",
                                                            "14/05/1987",
                                                            15.80);
        
        FuncionarioMensalista funcMens = new FuncionarioMensalista(849,
                                                            "Yolanda",
                                                            "20/09/1996",
                                                            2000);
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(621,
                                                            "Vitor",
                                                            "09/10/2014",
                                                            10);
                
        funcHor.setQtdeHorTrab(90);
        funcHor.setCargo("Motorista");
        System.out.println("Registro: " + funcHor.getRegistro());
        System.out.println("Nome: " + funcHor.getNome());
        System.out.println("Data Admissão: " + funcHor.getDtAdmissao());
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salário Bruto: R$" + df.format(funcHor.calcSalBruto()));
        System.out.println("Desconto: R$" + df.format(funcHor.calcDesconto()));
        System.out.println("Gratificação: R$" + df.format(funcHor.calcGratificacao()));
        System.out.println("Salário Liquido: R$" + df.format(funcHor.calcSalLiquido()));
        
        
        funcMens.setCargo("Secretária");
        funcMens.setNumSalMin(3);
        funcMens.setValSalMin(2000);
        System.out.println("\n\nRegistro: " + funcMens.getRegistro());
        System.out.println("Nome: " + funcMens.getNome());
        System.out.println("Data Admissão: " + funcMens.getDtAdmissao());
        System.out.println("Cargo: " + funcMens.getCargo());
        System.out.println("Salário Bruto: R$" + df.format(funcMens.calcSalBruto()));
        System.out.println("Desconto: R$" + df.format(funcMens.calcDesconto()));
        System.out.println("Salário Liquido: R$" + df.format(funcMens.calcSalLiquido()));
        
        
        funcCom.setCargo("Vendedor");
        funcCom.setSalBase(3000);
        funcCom.addVendas(15000);
        System.out.println("\n\nRegistro: " + funcCom.getRegistro());
        System.out.println("Nome: " + funcCom.getNome());
        System.out.println("Data Admissão: " + funcCom.getDtAdmissao());
        System.out.println("Total de vendas: " + funcCom.getTotalVendas());
        System.out.println("Cargo: " + funcCom.getCargo());
        System.out.println("Taxa de Comissão: " + funcCom.getTaxaComissao() + "%");
        System.out.println("Salário Bruto: R$" + df.format(funcCom.calcSalBruto()));
        System.out.println("Salário Liquido: R$" + df.format(funcCom.calcSalLiquido()));
        System.out.println("Desconto: R$" + df.format(funcCom.calcDesconto()));
        System.out.println("Valor da gratificação: R$" + df.format(funcCom.calcGratificacao()));

    }
       
}
