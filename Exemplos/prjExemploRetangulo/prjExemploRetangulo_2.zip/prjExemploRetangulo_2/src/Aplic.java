
import java.util.Scanner;

/**
 *
 * @author romerac
 */
public class Aplic {

    public static void main(String[] args) {

        Scanner entrada = new Scanner (System.in);
        
        double medAlt, medBase;
        int opcao;
        
        System.out.println("Digite a medida da altura: ");
        medAlt = entrada.nextDouble();
        
        
        System.out.println("Digite a medida da base: ");
        medBase = entrada.nextDouble();
        
        
        // Instanciação de um objeto da classe Retangulo.
        Retangulo objRet = new Retangulo();
        
        //Passagem de mensagem 
        objRet.setAltura(medAlt);
        objRet.setBase(medBase);
        
        System.out.println("Medida do altura do retângulo: " + objRet.getAltura());
        System.out.println("Medida do base do retângulo: " + objRet.getBase());
        
        //MENU
            System.out.println("\n\n-1. Consultar área.");
            System.out.println("-2. Consultar perímetro.");
            System.out.println("-3. Consultar diagonal.");
            System.out.println("-4. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
        
        do{
            
            
            //
            opcao = entrada.nextInt();
            
            switch (opcao) {
                case 1:
                    System.out.println("Medida da área do retângulo: " + objRet.calcArea());
                    break;
                case 2:
                    System.out.println("Medida do perímetro do retângulo: " + objRet.calcPerimetro());
                    break;
                case 3:
                    System.out.println("Medida da diagonal do retângulo: " + objRet.calcDiagonal());
                    break;
                default:
                    break;
            }
            
        }while (opcao < 4);
        
    }
}
