import java.util.Scanner;

/**
 *
 * @author Fatec
 */
public class Aplic {

    
    public static void main(String[] args) {
       
        int mRA;
        int opcao;
        double mP1, mP2, mT1, mT2;
        
        Aluno aluno = new Aluno();
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Digite o RA do aluno: ");
        mRA = entrada.nextInt();
        
        System.out.print("Digite a nota da primeira prova: ");
        mP1 = entrada.nextDouble();
        
        System.out.print("Digite a nota da segunda prova: ");
        mP2 = entrada.nextDouble(); 
        
        System.out.print("Digite a nota do primeiro trabalho: ");
        mT1 = entrada.nextDouble();

        System.out.print("Digite a nota do segundo trabalho: ");
        mT2 = entrada.nextDouble();
        
        aluno.setRA(mRA);
        aluno.setNtPrv1(mP1);
        aluno.setNtPrv2(mP2);
        aluno.setNtTrab1(mT1);
        aluno.setNtTrab2(mT2);
        
        do{
            System.out.println("\n\n1 - Exibir nota das Provas / Trabalho");
            System.out.println("2 - Exibir média das Provas / Trabalhos");
            System.out.println("3- Exibir média Final");
            System.out.println("4 - Sair");
            System.out.print("\n\t\tDigite a opcao:");
            opcao = entrada.nextInt();
        
            
            System.out.println("\nRA: " + aluno.getRA());

            switch (opcao) {
                case 1:
                    System.out.println("Nota da P1: " + aluno.getNtPrv1() + "\nNota da P2: " + aluno.getNtPrv2());
                    System.out.println("Nota do 1°trabalho: " + aluno.getNtTrab1() + "\nNota do 2°trabalho: " + aluno.getNtTrab2());
                    break;
                case 2:
                    System.out.println("Média das provas: " + aluno.calcMediaProva());
                    System.out.println("Média dos trabalhos: " + aluno.calcMediaTrab());
                    break;
                case 3:
                    System.out.println("Média final: " + aluno.calcMediaFinal());
                    break;               
            }
        }while(opcao < 4);
    }
}
