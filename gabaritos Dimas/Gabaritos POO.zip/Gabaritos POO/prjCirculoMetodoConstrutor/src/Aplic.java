
import java.util.Scanner;

/**
 *
 * @author Fatec
 * 
 */
public class Aplic {
    public static void main(String[] args) {
        double medRaio;
        int opcao;
        String unidade;
                
        //Instanciação de um objeto da classe Scanner
        Scanner entrada = new Scanner(System.in);
         
        System.out.print("Digite a unidade de medida: ");
        unidade = entrada.next(); //scanf("%s", &unidade)
        
        //Instanciação de um objeto da classe Circulo
        //e chamada do método construtor
        Circulo objCirc = new Circulo(unidade);
        
        System.out.print("Digite a medida raio do circulo: ");
        medRaio = entrada.nextDouble();
        objCirc.setRaio(medRaio);
        
        do{
            System.out.println("\n\n1 - Consultar medida da área");
            System.out.println("2 - Consultar medida do perímetro");
            System.out.println("3 - Consultar medida da diâmetro");
            System.out.println("4 - Encerrar");
            System.out.print("\n\t\tDigite a opção: ");
            opcao = entrada.nextInt(); 
            
	    System.out.println("\n\nMedida do raio do círculo: " + objCirc.getRaio() +
                               " " + objCirc.getUnidadeMedida());
            if (opcao == 1){
                System.out.println("Medida da área: " + objCirc.calcArea() +
                                   " " + objCirc.getUnidadeMedida() + "²");
            }else
               if (opcao == 2){
                   System.out.println("Medida do perímetro: " + objCirc.calcPerimetro() +
                                      " " + objCirc.getUnidadeMedida());      
               }else
                  if (opcao == 3){
                      System.out.println("Medida do diâmetro: " + objCirc.calcDiametro() +
                                         " " + objCirc.getUnidadeMedida());
                  } 
        }while(opcao < 4);
    }
}
