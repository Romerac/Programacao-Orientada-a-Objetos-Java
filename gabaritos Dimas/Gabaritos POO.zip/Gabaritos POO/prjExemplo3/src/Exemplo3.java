/**
 *
 * @author Dimas
 */
public class Exemplo3 {
    public static void main(String[] args) {
        int num;
        
        num = (int)(Math.random() * 100);
        
        if (num <= 50){
            System.out.println("O númmero " + num + " é menor ou igual a 50");
        }else{
            System.out.println("O númmero " + num + " maior que 50");
        }
    }
    
}
