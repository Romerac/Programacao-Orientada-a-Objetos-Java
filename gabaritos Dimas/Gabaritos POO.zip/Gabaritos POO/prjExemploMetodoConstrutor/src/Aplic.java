
import java.util.Scanner;

/**
 *
 * @author Fatec
 */
public class Aplic {    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double medAlt, medBase;
        int opcao;
        String unidade;
        
        System.out.print("Digite a unidade de medida: ");
        unidade = entrada.next();
        //Instanciação de um obejto da classe Retangulo
        //e chamada do método construtor
        Retangulo objRet = new Retangulo(unidade);
        
        System.out.print("Digite a medida da altura: ");
        medAlt = entrada.nextDouble();
        System.out.print("Digite a medida da base: ");
        medBase = entrada.nextDouble();  
        
        //Passagem de mensagens 
        objRet.setAltura(medAlt);
        objRet.setBase(medBase); 
        
        do{           
           System.out.println("\n\n1-Consultar área"); 
           System.out.println("2-Consultar perímetro");
           System.out.println("3-Consultar diagonal");
           System.out.println("4-Sair");
           System.out.print("\n\t\tDigite sua opção: ");
           opcao = entrada.nextInt();
           
           System.out.println("\nMedida da altura do retângulo: " + 
                              objRet.getAltura() + " " + 
                              objRet.getUnidadeMedida());
           System.out.println("Medida da base do retângulo: " +
                              objRet.getBase() + " " + 
                              objRet.getUnidadeMedida()); 
           if (opcao == 1){
               System.out.println("Medida da área do retângulo: " + 
                                  objRet.calcArea()+ " " + 
                                  objRet.getUnidadeMedida() + "²");
           }else
              if (opcao == 2){ 
                  System.out.println("Medida do perímetro do retângulo: " +
                                    objRet.calcPerimetro()+ " " + 
                                    objRet.getUnidadeMedida());
              }else
                 if (opcao == 3){ 
                     System.out.println("Medida da diagonal do retângulo: " +
                                         objRet.calcDiagonal()+ " " + 
                                         objRet.getUnidadeMedida());
                 }    
        }while(opcao < 4);        
    }    
}
