/**
 *
 * @author Fatec
 */

import java.util.Scanner;

public class Aplic {
    public static void main(String[] args) {
            Scanner entrada = new Scanner(System.in);
            int id, opcao, qtdeDias;
            String titulo;
            double valMultaDiaria, valPagar;
            
            System.out.print("Digite a identificação do livro: ");
            id = entrada.nextInt();  
            entrada.nextLine();
            System.out.print("Digite o título do livro: ");
            titulo = entrada.nextLine();
                        
            //Instanciação do objeto da classe Livro
            //faz a chamada do método construtor
            Livro objLivro = new Livro(id, titulo);
            
            System.out.print("Digite a multa diaria: ");
            valMultaDiaria = entrada.nextDouble();
            objLivro.setValMultaDiaria(valMultaDiaria);
            
            do {
                System.out.println("\n\n1 - Consultar livro");
                System.out.println("2 - Emprestar livro");
                System.out.println("3 - Devolver livro");
                System.out.println("4 - Sair");
                System.out.print("\n\tOpcao: ");
                opcao = entrada.nextInt();
                
                switch (opcao) {
                    case 1 : 
                        System.out.println("\nIdentificação: " + objLivro.getIdentificacao());
                        System.out.println("Titulo: " + objLivro.getTitulo());
                        if (objLivro.getSituacao() == true){
                            System.out.println("Situacao: Emprestado");
                        }    
                        else{
                            System.out.println("Situacao: Disponível");
                        }
                        break;
                        
                    case 2 : 
                        if (objLivro.getSituacao()){
                            System.out.println("\nO livro está emprestado");                           
                        }else{
                            objLivro.emprestar();
                            System.out.println("\nOperação de empréstimo realizada com sucesso");                            
                        }    
                        break;
                             
                    case 3 : 
                        if (objLivro.getSituacao()){
                           System.out.print("Digite a qtde. de dias de atraso: ");
                           qtdeDias = entrada.nextInt();
                           valPagar = objLivro.devolver(qtdeDias);
                           System.out.println("\nOperação de devolução realizada com sucesso");
                           if (valPagar > 0){
                               System.out.println("\nValor da multa: " + valPagar);
                           }
                        }else{
                            System.out.println("\nO livro já está disponível");
                        }   
                        break;                        
                }
            }while (opcao < 4);        
    }
}

