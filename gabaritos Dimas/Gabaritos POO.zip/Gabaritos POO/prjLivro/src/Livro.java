/**
 *
 * @author Fatec
 */

public class Livro {
    private int identificacao;
    private String titulo;
    private boolean situacao; 
    private double valMultaDiaria;

    public Livro(int ident, String tit) {
        identificacao = ident;
        titulo = tit;
    }

    public int getIdentificacao() { 
        return identificacao;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public boolean getSituacao() { 
        return situacao;
    }
    public void setValMultaDiaria(double multa) { 
        valMultaDiaria = multa; 
    }

    public void emprestar() {
           situacao = true;  //Emprestado          
    }

    public double devolver(int diasAtraso) {       
        situacao = false; //Disponível
        return(diasAtraso * valMultaDiaria);
    }
}

