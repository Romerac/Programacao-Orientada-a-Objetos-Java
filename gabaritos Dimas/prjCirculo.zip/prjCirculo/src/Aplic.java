
import java.util.Scanner;

/**
 *
 * @author Fatec
 */
public class Aplic {
    public static void main(String[] args) {
        double medRaio;
        int opcao;
                
        //Instanciação de um objeto da classe Scanner
        Scanner entrada = new Scanner(System.in);
        System.out.print("Digite a medida raio do circulo: ");
        medRaio = entrada.nextDouble(); 
        
        //Instanciação de um objeto da classe Circulo
        Circulo objCirc = new Circulo();
        objCirc.setRaio(medRaio);
        
        do{
            System.out.println("\n\n1 - Consultar medida da área");
            System.out.println("2 - Consultar medida do perímetro");
            System.out.println("3 - Consultar medida da diâmetro");
            System.out.println("4 - Encerrar");
            System.out.print("\n\t\tDigite a opção: ");
            opcao = entrada.nextInt(); 
            
	    System.out.println("\n\nMedida do raio do círculo: " + objCirc.getRaio());
            if (opcao == 1){
                System.out.println("\n\nMedida da área: " + objCirc.calcArea());
            }else
               if (opcao == 2){
                   System.out.println("\n\nMedida do perímetro: " + objCirc.calcPerimetro());       
               }else
                  if (opcao == 3){
                      System.out.println("\n\nMedida do diâmetro: " + objCirc.calcDiametro());
                  } 
        }while(opcao < 4);
    }
}
