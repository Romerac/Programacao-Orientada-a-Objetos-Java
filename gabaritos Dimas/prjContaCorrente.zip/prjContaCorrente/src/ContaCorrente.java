

/**
 *
 * @author Fatec
 *
 */
public class ContaCorrente {
    private int numero;
    private double saldo;

    //Método construtor
    public ContaCorrente(int n, double s) {
        numero = n;
        saldo = s;
    }
    public int getNumero() {
        return numero;
    }
    public double getSaldo() {
        return saldo;
    }
    public void sacar(double saque){
        saldo -= saque; //saldo = saldo - saque
    }    
    public void depositar(double deposito){
         saldo += deposito; //saldo = saldo + deposito
    }
}
