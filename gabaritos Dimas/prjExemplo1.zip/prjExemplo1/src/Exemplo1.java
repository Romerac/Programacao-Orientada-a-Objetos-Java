
/**
 *
 * @author Dimas
 */
public class Exemplo1 {
    public static void main(String[] args) {
       System.out.print("Programação Orientada a Objetos");
    }    
}
