
import java.util.Scanner;

/**
 *
 * @author romerac
 */
public class Aplic {


     public static void main(String[] args) {
         
         Scanner Entrada = new Scanner (System.in);
         
         
            int codRA;
            int opcao;
         
         System.out.println("Digite o código do RA do aluno: ");
         codRA = Entrada.nextInt();
         
         //Instanciação:
         
         Aluno objAluno = new Aluno();
         
         objAluno.setRA(codRA);
         
         System.out.println("Aluno RA: " + objAluno.getRA());
         
         do{
            //MENU
            
            System.out.println("\n\n-1. Digitar nota prova 1");
            System.out.println("-2. Digitar nota Prova 2.");
            System.out.println("-3. Digitar nota Trabalho 1.");
            System.out.println("-4. Digitar nota Trabalho 2.");
            System.out.println("-5. Mostrar média das provas: ");
            System.out.println("-6. Mostrar média dos trabalhos: ");
            System.out.println("-7. Mostrar média final: ");
            System.out.println("-8. Mostrar boletim do aluno de RA: " + objAluno.getRA());
            System.out.println("-9. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
            
            
            //
            opcao = Entrada.nextInt();
            
            switch (opcao) {
                case 1:
                    double nota1; 
                    System.out.println("\nNota prova 1 (no padrão 0.0): ");
                    nota1 = Entrada.nextDouble();
                    objAluno.setNtPrv1(nota1);
                    break;
                case 2:
                    double nota2; 
                    System.out.println("\nNota prova 2 (no padrão 0.0): ");
                    nota2 = Entrada.nextDouble();
                    objAluno.setNtPrv2(nota2);
                    break;
                case 3:
                    double trab1; 
                    System.out.println("\nNota trabalho 1 (no padrão 0.0): ");
                    trab1 = Entrada.nextDouble();
                    objAluno.setNtTrab1(trab1);
                    break;
                case 4:
                    double trab2; 
                    System.out.println("\nNota trabalho 2 (no padrão 0.0): ");
                    trab2 = Entrada.nextDouble();
                    objAluno.setNtTrab2(trab2); 
                    break;
                case 5:
                    System.out.println("\nMédia das provas: " + objAluno.calcMediaProva());
                    break;
                case 6:
                    System.out.println("\nMédia dos trabalhos: " + objAluno.calcMediaTrab());
                    break;
                case 7:
                    System.out.println("\nMédia Final: " + objAluno.calcMediaFinal());
                    break;
                case 8:
                    System.out.println("\nBoletim do aluno de RA " + objAluno.getRA() + ": " + 
                            "\nProva : " +
                            + objAluno.getNtPrv1() +
                            "\nProva 2: " +
                            + objAluno.getNtPrv2() + 
                            "\nTrabalho 1: " +
                            + objAluno.getNtTrab1() + 
                            "\nTrabalho 2: " +
                            + objAluno.getNtTrab2() + 
                            "\nMedia das provas: " +
                            + objAluno.calcMediaProva() + 
                            "\nMedia dos trabalhos: "
                            + objAluno.calcMediaTrab() + 
                            "\nMedia final: "
                            + objAluno.calcMediaFinal());
                    break;
                default:
                    break;
            }
            
        }while (opcao < 9);
    }
    
}
