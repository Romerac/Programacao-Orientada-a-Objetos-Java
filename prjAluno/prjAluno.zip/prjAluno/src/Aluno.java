
/**
 *
 * @author romerac
 */
public class Aluno {
    
    private int RA;
    private double Prova1, Prova2, Trab1, Trab2;
    
    
    public void setRA(int r){
        RA = r;
    }
    
    public int getRA(){
        return(RA);
    }
    
    public void setNtPrv1 (double p){
        Prova1 = p;
    }
    
    public double getNtPrv1(){
        return(Prova1);
    }
    
    public void setNtPrv2 (double p){
        Prova2 = p;
    }
    
    public double getNtPrv2 (){
        return(Prova2);
    }
    
    public void setNtTrab1 (double t){
        Trab1 = t;
    }
    
    public double getNtTrab1(){
        return(Trab1);
    }
    
    public void setNtTrab2 (double t){
        Trab2 = t;
    }
    
    public double getNtTrab2(){
        return(Trab2);
    }
    
    public double calcMediaProva(){
        return(0.75 * (Prova1 + 2 * Prova2)/3);
    }
    
    public double calcMediaTrab(){
        return(0.25 * ((Trab1 + Trab2)/ 2));
    }
    
    public double calcMediaFinal(){
        return (calcMediaTrab() + calcMediaProva());
    }
    
}
