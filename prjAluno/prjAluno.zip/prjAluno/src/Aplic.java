
import java.util.Scanner;

/**
 *
 * @author romerac
 */
public class Aplic {


     public static void main(String[] args) {
         
         Scanner Entrada = new Scanner (System.in);
         
         
            int codRA;
            int opcao;
         
            double nota1; 
            double nota2;
            double trab1; 
            double trab2; 
            
            
            
         System.out.println("Digite o código do RA do aluno: ");
         codRA = Entrada.nextInt();
         
         //Instanciação:
         
         Aluno objAluno = new Aluno();
         
         objAluno.setRA(codRA);
         
         System.out.println("Aluno RA: " + objAluno.getRA());
         
         System.out.println("\nNota prova 1 (no padrão 0.0): ");
                    nota1 = Entrada.nextDouble();
                    objAluno.setNtPrv1(nota1);
          
         System.out.println("\nNota prova 2 (no padrão 0.0): ");
                    nota2 = Entrada.nextDouble();
                    objAluno.setNtPrv2(nota2);
         
         System.out.println("\nNota trabalho 1 (no padrão 0.0): ");
                    trab1 = Entrada.nextDouble();
                    objAluno.setNtTrab1(trab1);
               
         System.out.println("\nNota trabalho 2 (no padrão 0.0): ");
                    trab2 = Entrada.nextDouble();
                    objAluno.setNtTrab2(trab2); 

         do{
            //MENU
            
            System.out.println("\n\n-1. Exibir Nota das Provas/Trabalhos.");
            System.out.println("-2. Exibir Média dos Trabalhos/Provas.");
            System.out.println("-3. Exibir Média Final");
            System.out.println("-4. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
            
            
            //
            opcao = Entrada.nextInt();
            
            switch (opcao) {
                case 1:
                    System.out.println("\nNotas das Provas/Trabalho do aluno de RA " + objAluno.getRA() + ": " + 
                            "\nProva : " +
                            + objAluno.getNtPrv1() +
                            "\nProva 2: " +
                            + objAluno.getNtPrv2() + 
                            "\nTrabalho 1: " +
                            + objAluno.getNtTrab1() + 
                            "\nTrabalho 2: " +
                            + objAluno.getNtTrab2());
                    break;
                    
                case 2:
                    System.out.println("\nMédias das Provas/Trabalho do aluno de RA " + objAluno.getRA() + ": "
                                     + "\nMédia dos trabalhos: " + objAluno.calcMediaTrab()
                                     + "\nMédia das provas: " + objAluno.calcMediaProva()
                                     );
                    break;
                case 3:
                    System.out.println("\nMédia Final do aluno de RA " + objAluno.getRA() + ": "
                                     + objAluno.calcMediaFinal());                    
                    break;

                default:
                    break;
            }
            
        }while (opcao < 4);
    }
    
}
