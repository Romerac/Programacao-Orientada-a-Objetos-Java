
import java.util.Scanner;

/**
 *
 * @author romerac
 */
public class Aplic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner Entrada = new Scanner(System.in);
        int opcao;
        int codConta;
        double valSaldo;
        double valSaq;
        double valDep;

        
        System.out.println("Digite o Número da conta e o Saldo inicial desta Conta Corrente:");
        codConta = Entrada.nextInt();
        valSaldo = Entrada.nextDouble();
        
        // Instanciação de um objeto da classe ContaCorrente
        //e chamada do método construtor.
        ContaCorrente objContaCorrente = new ContaCorrente(codConta, valSaldo);
        
        
        
    
        do{
//MENU
            System.out.println("\n\n-1. Depositar");
            System.out.println("-2. Sacar");
            System.out.println("-3. Consultar Saldo.");
            System.out.println("-4. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
            
            
            //
            opcao = Entrada.nextInt();
            switch (opcao){

            case 1:
                System.out.println("Conta: " + objContaCorrente.getNumero() + "\n");
                System.out.println("Digite o valor a ser depositado:");
                valDep = Entrada.nextDouble();
                objContaCorrente.depositar(valDep);
                break;
            case 2:
                System.out.println("Conta: " + objContaCorrente.getNumero() + "\n");
                System.out.println("Digite o valor a ser sacado:");
                valSaq = Entrada.nextDouble();
                
                if(valSaq <= objContaCorrente.getSaldo()){
                    objContaCorrente.sacar(valSaq);
                }
                else{
                    System.out.println("\t\t\t SALDO INSUFICIENTE");
                }
                break;
            case 3:
                System.out.println("Conta: " + objContaCorrente.getNumero() + "\n");
                System.out.println("Saldo atual: "+ objContaCorrente.getSaldo());
                
                break;
            default:
                break;

            }

        }while(opcao<4);

    }
    
}
