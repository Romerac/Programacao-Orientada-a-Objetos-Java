/**
 *
 * @author romerac
 */
public class ContaCorrente {
    
    private int numero;
    private double saldo;
    
    
    public ContaCorrente(int codConta, double valSaldo){
        numero = codConta;
        saldo = valSaldo;
    }
    
    public int getNumero(){
        return(numero);
    }
    
    public double getSaldo(){
        return(saldo);
    }
    
    
    public void sacar(double valSaq){
        saldo -= valSaq;
    }
    
    public void depositar(double valDep){
        saldo += valDep;
    }
    
    
    
}
