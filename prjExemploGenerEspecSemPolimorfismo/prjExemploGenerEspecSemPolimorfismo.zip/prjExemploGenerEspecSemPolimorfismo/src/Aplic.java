
import fatec.poo.model.Aluno;
import fatec.poo.model.Professor;


/*
 * @author romerac
 */
public class Aplic {

    public static void main(String[] args) {
        //instanciação do objeto e chamada do método construtor
        Aluno objAluno = new Aluno(1010, "Carlos Silveira", "15/03/1978");
        
        //passagem mensagens
        objAluno.setMensalidade(1500);
        
        System.out.println("Registro escolar: " + objAluno.getRegEscolar());
        System.out.println("Nome: " + objAluno.getNome());
        System.out.println("Data de Nascimento: " + objAluno.getDataNascimento());
        System.out.println("Mensalidade: " + objAluno.getMensalidade());
        
        
        System.out.println("\n==============================================\n");
        
        //instanciação do objeto e chamada do método construtor
        Professor objProfessor = new Professor(1123, "José David", "16/05/1941");
        
        //passagem mensagens (dados)
        objProfessor.setSalario(30201);
        
        System.out.println("Registro funcional: " + objProfessor.getRegFuncional());
        System.out.println("Nome: " + objProfessor.getNome());
        System.out.println("Data de Nascimento: " + objProfessor.getDataNascimento());
        System.out.println("Mensalidade: " + objProfessor.getSalario());
        
    }
       
}
