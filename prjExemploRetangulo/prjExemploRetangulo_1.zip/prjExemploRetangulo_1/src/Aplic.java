/**
 *
 * @author romerac
 */
public class Aplic {
    public static void main(String[] args) {
        
    //Definição do ponteiro para um objeto:
    Retangulo objRet;

    //Instanciação (alocação):
    objRet = new Retangulo();
    
    //Passagem de mensagens
    objRet.setAltura(5.0);
    objRet.setBase(8.0);
    
    System.out.println("Medida da área do retângulo: " + objRet.calcArea());
    System.out.println("Medida do perímetro do retângulo: " + objRet.calcPerimetro());
    System.out.println("Medida do altura do retângulo: " + objRet.getAltura());
    System.out.println("Medida do base do retângulo: " + objRet.getBase());
    System.out.println("Medida da diagonal do retângulo: " + objRet.calcDiagonal());
       
    
    //Define ponteiro e instancia (aloca):
    Retangulo objRet1 = new Retangulo();
    
    objRet1.setAltura(3.0);
    objRet1.setBase(4.0);
    
    System.out.println("Medida da área do retângulo: " + objRet1.calcArea());
    System.out.println("Medida do perímetro do retângulo: " + objRet1.calcPerimetro());
    System.out.println("Medida do altura do retângulo: " + objRet1.getAltura());
    System.out.println("Medida do base do retângulo: " + objRet1.getBase());
    System.out.println("Medida da diagonal do retângulo: " + objRet1.calcDiagonal());
    
    
    }
}