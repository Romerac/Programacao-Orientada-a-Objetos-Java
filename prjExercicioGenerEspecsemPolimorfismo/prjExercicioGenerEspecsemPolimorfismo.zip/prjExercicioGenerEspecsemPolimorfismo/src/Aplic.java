import fatec.poo.model.Instrutor;
import fatec.poo.model.Cliente;

/**
 *
 * @author Romerac
 */
public class Aplic {

    public static void main(String[] args) {
        //instanciação e chamada construtor
        Instrutor objInstrutor = new Instrutor(11023, "Renato Pereira", "3321-1230");
            
        //passagem mensagens
        objInstrutor.setAreaAtuacao("Professor de Muay Thai");
        
        System.out.println("\n==============================================\n");
        System.out.println("ID: " + objInstrutor.getIdentificacao());
        System.out.println("Nome: " + objInstrutor.getNome());
        System.out.println("Telefone: " + objInstrutor.getTelefone());
        System.out.println("Area de atuação: " + objInstrutor.getAreaAtuacao());
        
        System.out.println("\n==============================================\n");
        
        //instanciação e chamada construtor
        Cliente objCliente = new Cliente("628.755.120-80", "Felipe Fonseca", "99816-9161");
        
        objCliente.setAltura(1.89);
        objCliente.setPeso(85.2);
                    
        //passagem mensagens
        System.out.println("CPF: " + objCliente.getCPF());
        System.out.println("Nome: " + objCliente.getNome());
        System.out.println("Telefone: " + objCliente.getTelefone());
        System.out.println("Peso: " + objCliente.getPeso());
        System.out.println("Altura: " + objCliente.getAltura());
        
           System.out.println("\n==============================================\n");
    }
}