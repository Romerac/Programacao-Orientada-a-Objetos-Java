package fatec.poo.model;

/**
 *
 * @author Romerac
 */
public class Cliente extends Pessoa{
    private String cpf;
    private double peso;
    private double altura;
    
    public Cliente(String id, String n, String t){
        super(n, t);
        cpf = id;
    }
    
    public void setPeso(double p){
        peso = p;
    }
    
    public void setAltura (double a){
        altura = a;
    }
    
    public String getCPF(){
        return(cpf);
    }
    
    public double getPeso(){
        return(peso);
    }
    
    public double getAltura(){
        return(altura);
    }
    
}
