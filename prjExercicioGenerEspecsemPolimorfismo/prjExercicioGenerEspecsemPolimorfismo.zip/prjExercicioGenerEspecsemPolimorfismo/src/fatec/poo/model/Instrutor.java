package fatec.poo.model;

/**
 *
 * @author Romerac
 */
public class Instrutor extends Pessoa{
    private int identificador;
    private String areaAtuacao;
    
    public Instrutor (int id, String n, String t)  {
        super (n, t);
        identificador = id;
    }
    
    public void setAreaAtuacao(String a){
        areaAtuacao = a;
    }
    
    public int getIdentificacao(){
        return(identificador);
    }
    
    public String getAreaAtuacao(){
        return(areaAtuacao);
    }
}
