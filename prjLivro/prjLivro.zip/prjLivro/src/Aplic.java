
import java.util.Scanner;

/**
 *
 * @author Romerac
 */
public class Aplic {

    public static void main(String[] args) {
        Scanner Entrada = new Scanner (System.in);
        
        int opcao;
        int codIdentificacao;
        String titulo;
        boolean situacao = false;
        int qtdeDiasAtraso;
        double valMultaDiaria;
        
        
        System.out.println("Digite o Código de Identificação do livro e seu respectivo Título: ");
        codIdentificacao = Entrada.nextInt();
        Entrada.nextLine(); // LIMPANDO O BUFFER PARA APAGAR O ENTER (se não limpar, ele pula a instrução abaixo)
        titulo = Entrada.nextLine();
        
        // Instanciação de um objeto da classe ContaCorrente
        //e chamada do método construtor.
        Livro objLivro = new Livro(codIdentificacao, titulo);
        
        System.out.println("Digite o valor da multa diária por atraso: ");
        valMultaDiaria = Entrada.nextDouble();
        
        do{
            //MENU
            System.out.println("\n-1. Consultar livro.");
            System.out.println("-2. Emprestar livro.");
            System.out.println("-3. Devolver livro.");
            System.out.println("-4. Sair.");
            System.out.println("\n\n-Digite sua opção: ");
            opcao = Entrada.nextInt();
            
            switch(opcao){
                    case 1:
                        System.out.println("==============================================================");
                        System.out.println("\t\tConsulta de livros:\n");
                        System.out.println("Identificação: " + objLivro.getIdentificacao());
                        System.out.println("Titulo: " + objLivro.getTitulo());
                        
                        if(objLivro.getSituacao()){
                            System.out.println("\nLivro está alugado e indisponível no momento.");
                        }else{
                            System.out.println("\nO livro está disponível no acervo da biblioteca.");
                        }
                        System.out.println("=============================================================="); 
                        break;
                        
                    case 2:
                        System.out.println("==============================================================");
                        System.out.println("\t\tEmprestar livro:\n");
                        System.out.println("\nDigite o código do livro que deseja alugar: ");
                        //codIdentificacao = Entrada.nextInt();
                        System.out.println("Identificação: " + objLivro.getIdentificacao());
                        System.out.println("Titulo: " + objLivro.getTitulo());
                        if(objLivro.getSituacao()){
                            System.out.println("O livro está emprestado!");
                            
                        }else{
                            objLivro.emprestar();
                            System.out.println("\nOperação de empréstimo realizada com sucesso!");
                        }                        
                        System.out.println("=============================================================="); 
                        break;
                        
                    case 3:
                        System.out.println("==============================================================");
                        System.out.println("\tDevolver livro:\n");
                        System.out.println("\nDigite o código do livro que deseja devolver: ");
                        //codIdentificacao = Entrada.nextInt();
                        
                        System.out.println("Caso haja atraso, digite a quantidade de dias em atraso. Se não houver atraso, digite 0:");
                        qtdeDiasAtraso = Entrada.nextInt();
                        
                        System.out.println("\nIdentificação: " + objLivro.getIdentificacao());
                        System.out.println("Titulo: " + objLivro.getTitulo());
                        
                        
                        if(objLivro.getSituacao()){
                            System.out.println("O valor da multa de atraso da devolução é: R$" + objLivro.devolver(qtdeDiasAtraso, valMultaDiaria) + ". Por gentileza, pague no caixa.");
                            System.out.println("\nOperação de devolução realizada com sucesso!");
                        }else{
                            System.out.println("O livro já está disponível!");
                            
                        }
                        System.out.println("=============================================================="); 
                        break;
            }
        }while (opcao != 4);
    }
}
