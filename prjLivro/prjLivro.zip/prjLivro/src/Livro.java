/**
 *
 * @author Romerac
 */
public class Livro {
    private int identificacao;
    private String titulo;
    private boolean situacao = false;
    private double valMultaDiaria;
    
    public Livro (int i, String s){
        identificacao = i;
        titulo = s;
    }
    
    public void setValMultaDiaria(double valor){
        valMultaDiaria = valor;
    }
    
    public int getIdentificacao(){
        return(identificacao);
    }
    
    public String getTitulo(){
        return(titulo);
    }
    
    public boolean getSituacao(){
        return(situacao);
    }
    
    public void emprestar(){
        situacao = true;
    }
    
    public double devolver (int qtdeDiasAtraso, double valMultaDiaria){
        situacao = false;
        return(qtdeDiasAtraso * valMultaDiaria);
        
    }
    
    
    
    
}
